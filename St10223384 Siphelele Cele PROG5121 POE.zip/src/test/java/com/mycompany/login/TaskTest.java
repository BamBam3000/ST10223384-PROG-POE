/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.login;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */



public class TaskTest {
  @Test
    public void testTaskDescriptionLength() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue(task.checkTaskDescription()); // Success
        
        task = new Task("Long Task", "This description is way too long to be valid as it exceeds fifty characters", "Mike Smith", 10, "Doing");
        assertFalse(task.checkTaskDescription()); // Failure
    }

    @Test
    public void testTaskIDGeneration() {
        Task task1 = new Task("Login Feature", "Create Login", "Robyn Harrison", 8, "To Do");
        assertEquals("LO:1:HAR", task1.createTaskID());

        Task task2 = new Task("Add Task Feature", "Create Add Task feature", "Mike Smith", 10, "Doing");
        assertEquals("AD:2:SMI", task2.createTaskID());
    }

    @Test
    public void testTotalHoursAccumulation() 
    {
        EasyKanban tasksApp = new EasyKanban();
        tasksApp.addTask(new Task("Task 1", "Description", "Dev 1", 10, "To Do"));
        tasksApp.addTask(new Task("Task 2", "Description", "Dev 2", 12, "To Do"));
        
        assertEquals(22, tasksApp.returnTotalHours()); 

    }
}