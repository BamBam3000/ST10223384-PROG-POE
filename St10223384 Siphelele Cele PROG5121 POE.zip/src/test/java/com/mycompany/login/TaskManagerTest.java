/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.login;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */

public class TaskManagerTest {

    TaskManager taskManager = new TaskManager();

    @Test
    public void testDeveloperArrayPopulation() {
        assertEquals("Mike Smith", taskManager.developers.get(0));
        assertEquals("Edward Harrison", taskManager.developers.get(1));
        assertEquals("Samantha Paulson", taskManager.developers.get(2));
        assertEquals("Glenda Oberholzer", taskManager.developers.get(3));
    }

    @Test
    public void testDisplayLongestTask() {
        taskManager.longestDuration(); // Outputs to console; inspect manually or refactor for assertion
    }

    @Test
    public void testsearchTaskByName() {
        taskManager.searchTask("Create Login");
    }

    @Test
    public void testsearchtasksByDeveloper() {
        taskManager.tasksByDeveloper("Samantha Paulson");
    }

    @Test
    public void testDeleteTask() {
        taskManager.deleteTask("Create Reports");
        assertFalse(taskManager.taskNames.contains("Create Reports"));
    }

    @Test
    public void testDisplayReport() {
        taskManager.displayReport(); // Outputs to console; inspect manually or refactor for assertion
    }
}