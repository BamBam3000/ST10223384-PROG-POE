package com.mycompany.login;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
public class Task {
    private static int taskCounter = 0;
    private final String taskName;
    private final String taskDescription;
    private final String developerDetails;
    private final int taskDuration; // in hours
    private final String taskStatus; // "To Do", "Done", "Doing"
    private final String taskID;
    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
        taskCounter++;
    }
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }
    public String createTaskID() {
        String initials = taskName.substring(0, 2).toUpperCase();
        String developerInitials = developerDetails.split(" ")[1].substring(0, 3).toUpperCase();
        return String.format("%s:%d:%s", initials, taskCounter, developerInitials);
    }
    public String printTaskDetails() {
        return String.format("Task Status: %s\nDeveloper Details: %s\nTask Number: %d\nTask Name: %s\nTask Description: %s\nTask ID: %s\nDuration: %d hrs",
                taskStatus, developerDetails, taskCounter, taskName, taskDescription, taskID, taskDuration);
    }
    public int returnTotalHours() {
        return taskDuration;
    }
}
