package com.mycompany.login;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
public class EasyKanban {
private static List<Task> tasks = new ArrayList<>();
    private static int totalHours = 0;
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        if (!loginUser()) {
            return; // Exit if login fails
        }
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks do you wish to enter?"));
        while (true) {
            String menu = "1) Add tasks\n2) Show report\n3) Quit";
            String choice = JOptionPane.showInputDialog(menu);
            switch (choice) {
                case "1":
                    addTasks(numTasks);
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case "3":
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }
    private static boolean loginUser() {
        // Implement user login logic
        // Return true for successful login
        return true;
    }
    private static void addTasks(int numTasks) {
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter Task Name:");
            String taskDescription;
            while (true) {
                taskDescription = JOptionPane.showInputDialog("Enter Task Description (max 50 characters):");
                if (taskDescription.length() <= 50) break;
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
            }
            String developerDetails = JOptionPane.showInputDialog("Enter Developer Details (First Last):");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter Task Duration (in hours):"));
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Select Task Status:", "Task Status",
                    JOptionPane.QUESTION_MESSAGE, null, new String[]{"To Do", "Doing", "Done"}, "To Do");
            Task newTask = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
            tasks.add(newTask);
            totalHours += newTask.returnTotalHours();
            JOptionPane.showMessageDialog(null, newTask.printTaskDetails());
        }
        JOptionPane.showMessageDialog(null, "Total Hours: " + totalHours);
    }

    void addTask(Task task) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    short returnTotalHours() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


    

